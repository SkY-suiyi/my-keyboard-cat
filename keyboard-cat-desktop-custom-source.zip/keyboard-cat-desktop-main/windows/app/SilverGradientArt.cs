using System;
using System.Windows;
using System.Windows.Media;

// Animated silver-shaded cat, drawn in the original 480x320 scene coordinate space.
internal static class SilverGradientArt
{
    private static Color C(string s) { return (Color)ColorConverter.ConvertFromString(s); }
    private static Brush B(string a,string b)
    {
        var x=new LinearGradientBrush(C(a),C(b),new Point(.2,0),new Point(.8,1)); x.Freeze(); return x;
    }
    private static Brush S(string c) { var x=new SolidColorBrush(C(c)); x.Freeze(); return x; }
    private static Pen P(string c,double w)
    {
        var x=new Pen(S(c),w); x.StartLineCap=PenLineCap.Round; x.EndLineCap=PenLineCap.Round; x.LineJoin=PenLineJoin.Round; x.Freeze(); return x;
    }
    private static Geometry G(string d) { var x=Geometry.Parse(d); x.Freeze(); return x; }
    private static double L(double x,double a,double b) { return Math.Max(a,Math.Min(b,x)); }
    private static double Sm(double x) { x=L(x,0,1); return x*x*(3-2*x); }

    private static readonly Geometry Head=G("M -45,-20 C -47,-34 -43,-51 -38,-59 Q -34,-64 -29,-59 L -15,-44 Q 0,-49 15,-44 L 29,-59 Q 35,-65 39,-58 C 44,-48 47,-31 44,-19 Q 53,-5 45,12 Q 37,28 19,33 Q 0,39 -19,33 Q -39,27 -46,10 Q -52,-5 -45,-20 Z");
    private static readonly Geometry Body=G("M 175,105 C 170,128 169,149 163,169 C 157,190 157,213 165,229 Q 170,241 183,235 Q 208,242 237,234 Q 252,243 261,231 C 272,214 267,185 261,164 C 255,143 251,122 250,105 Z");
    private static readonly Geometry Tail=G("M 251,201 C 270,204 279,198 287,184 C 296,168 307,160 323,162 C 338,164 340,178 328,183 C 313,183 306,193 298,207 C 286,226 266,224 251,216 Z");
    private static readonly Brush Silver=B("#F0F2F4","#777F8A"), Face=B("#F5F6F7","#9BA3AD"), White=B("#FFFFFF","#E8EBEF");
    private static readonly Brush Green=B("#B8D96B","#5E963F"), Pink=S("#D99A9D"), Pupil=S("#202A22"), Glint=S("#FFFFFF");
    private static readonly Pen Edge=P("#68717C",1.05), Whisker=P("#68717C",.8), Toe=P("#C8CDD3",.8);
    private static readonly Geometry EyeShape=G("M -11,0 C -9,-8 -4,-10 1,-9 C 8,-8 12,-3 11,2 C 9,8 4,10 -1,9 C -7,8 -12,5 -11,0 Z");
    private static readonly Geometry ClosedEye=G("M -11,1 Q 0,7 11,0");

    private static void Eye(DrawingContext dc,int side,double gx,double gy,double blink)
    {
        dc.PushTransform(new TranslateTransform(side*19.5,-7));
        if(blink>.92) dc.DrawGeometry(null,P("#56634C",2),ClosedEye);
        else {
            dc.PushTransform(new ScaleTransform(1,Math.Max(.06,1-blink)));
            dc.DrawGeometry(Green,Edge,EyeShape); dc.PushClip(EyeShape);
            Point q=new Point(-.5+side*gx*4,gy*3);
            dc.DrawEllipse(Pupil,null,q,4.4,7); dc.DrawEllipse(Glint,null,new Point(q.X-1.7,q.Y-3),1.7,1.8);
            dc.Pop(); dc.Pop();
        }
        dc.Pop();
    }

    private static void FaceArt(DrawingContext dc,double gx,double gy,double blink,double t)
    {
        dc.DrawGeometry(Face,null,Head); dc.PushClip(Head);
        for(int i=0;i<5;i++) {
            double x=-37+i*18, sway=Math.Sin(t*1.2+i)*1.2;
            dc.DrawGeometry(null,P("#7C8590",2.8),G("M "+x+",-55 Q "+(x-5+sway)+",-40 "+(x+1)+",-27"));
            dc.DrawGeometry(null,P("#D9DDE2",1.2),G("M "+(x+3)+",-53 Q "+(x-1)+",-40 "+(x+5)+",-30"));
        }
        dc.DrawEllipse(White,null,new Point(-9,15),12,8); dc.DrawEllipse(White,null,new Point(9,15),12,8);
        dc.Pop();
        dc.DrawGeometry(Pink,null,G("M -4,10 Q 0,7 4,10 Q 5,13 0,15 Q -5,13 -4,10 Z"));
        dc.DrawGeometry(null,P("#77747A",.9),G("M 0,14 L 0,18 M 0,18 Q -5,22 -9,18 M 0,18 Q 5,22 9,18"));
        Eye(dc,-1,gx,gy,blink); Eye(dc,1,gx,gy,blink);
        dc.DrawGeometry(null,Whisker,G("M -18,14 Q -34,10 -48,12 M -18,18 Q -34,19 -47,23 M 18,14 Q 34,10 48,12 M 18,18 Q 34,19 47,23"));
        dc.DrawGeometry(Pink,null,G("M -39,-39 Q -38,-54 -33,-56 L -22,-44 Z M 22,-44 L 34,-56 Q 40,-52 40,-38 Z"));
    }

    private static void TailArt(DrawingContext dc,double t)
    {
        dc.PushTransform(new RotateTransform(Math.Sin(t*1.8)*3,258,207));
        dc.DrawGeometry(B("#B9C0C9","#68717D"),null,Tail); dc.PushClip(Tail);
        for(int i=0;i<4;i++) { double x=286+i*10; dc.DrawGeometry(null,P("#59636F",2.4),G("M "+x+",169 Q "+(x-8)+",190 "+(x-1)+",211")); }
        dc.Pop(); dc.Pop();
    }

    private static void Paw(DrawingContext dc,Point paw,bool left,double activity,double lean)
    {
        double side=left?-1:1; Point a=new Point(214+side*25-28*lean,143);
        Point b=new Point(a.X+(paw.X-a.X)*.28+side*5,a.Y+25);
        Point c=new Point(paw.X-(paw.X-a.X)*.16+side*4,paw.Y-18);
        var arm=new StreamGeometry();
        using(var g=arm.Open()) {
            g.BeginFigure(new Point(a.X-10,a.Y),true,true);
            g.BezierTo(b,c,new Point(paw.X+8,paw.Y),true,true);
            g.ArcTo(new Point(paw.X-8,paw.Y),new Size(8.5,8),0,false,SweepDirection.Clockwise,true,true);
            g.BezierTo(new Point(c.X-8,c.Y),new Point(b.X-10,b.Y),new Point(a.X+10,a.Y),true,true);
        }
        dc.DrawGeometry(Silver,null,arm); dc.DrawEllipse(White,null,paw,8.7,7.6);
        if(activity<.3) { dc.DrawLine(Toe,new Point(paw.X-2,paw.Y+2),new Point(paw.X-2,paw.Y+5)); dc.DrawLine(Toe,new Point(paw.X+2,paw.Y+2),new Point(paw.X+2,paw.Y+5)); }
    }

    public static void Draw(DrawingContext dc,double t,double gazeX,double gazeY,double blink,Point leftPaw,Point rightPaw,double leftActivity,double rightActivity)
    {
        double lean=Sm((157-leftPaw.X)/50), gx=L(gazeX,-1,1), gy=L(gazeY,-1,1);
        TailArt(dc,t);
        dc.PushTransform(new MatrixTransform(1,0,lean*.25,1,-58*lean,0));
        dc.DrawGeometry(Silver,null,Body); dc.PushClip(Body);
        dc.DrawGeometry(White,null,G("M 190,113 Q 214,130 239,112 Q 247,151 235,185 Q 216,205 197,184 Q 184,155 190,113 Z"));
        for(int i=0;i<4;i++) { double y=151+i*17; dc.DrawGeometry(null,P("#7C8590",2.5),G("M 164,"+y+" Q 184,"+(y-9)+" 199,"+(y+1))); dc.DrawGeometry(null,P("#7C8590",2.5),G("M 239,"+(y+1)+" Q 255,"+(y-8)+" 267,"+(y+5))); }
        dc.Pop(); dc.Pop();
        Paw(dc,rightPaw,false,rightActivity,lean); Paw(dc,leftPaw,true,leftActivity,lean);
        dc.PushTransform(new TranslateTransform(214-43*lean+gx*3,86+Math.Sin(t*1.7)*.7+gy*2+lean));
        dc.PushTransform(new RotateTransform(gx*2.5-lean*3)); FaceArt(dc,gx,gy,L(blink,0,1),t); dc.Pop(); dc.Pop();
    }

    public static void DrawPortrait(DrawingContext dc) { dc.PushTransform(new ScaleTransform(.86,.86)); FaceArt(dc,0,0,0,0); dc.Pop(); }
    public static bool ContainsHead(Point p,double time,double gx,double gy,Point leftPaw)
    {
        double lean=Sm((157-leftPaw.X)/50); Matrix m=Matrix.Identity;
        m.Rotate(gx*2.5-lean*3); m.Translate(214-43*lean+gx*3,86+Math.Sin(time*1.7)*.7+gy*2+lean); m.Invert();
        return Head.FillContains(m.Transform(p));
    }
}
